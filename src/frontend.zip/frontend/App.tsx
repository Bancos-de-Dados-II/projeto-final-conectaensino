import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

import AppErrorBoundary from "./components/system/AppErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import MainLayout from "./layouts/MainLayout";
import ProtectedRoute from "./routes/ProtectedRoute";

const Login = lazy(() => import("./pages/Login"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const MapPage = lazy(() => import("./pages/MapPage"));
const MonitorsPage = lazy(() => import("./pages/MonitorsPage"));
const StudentsPage = lazy(() => import("./pages/StudentsPage"));
const SessionsPage = lazy(() => import("./pages/SessionsPage"));
const InstitutionsPage = lazy(() => import("./pages/InstitutionsPage"));
const SubjectsPage = lazy(() => import("./pages/SubjectsPage"));
const CertificatesPage = lazy(() => import("./pages/CertificatesPage"));
const ReviewsPage = lazy(() => import("./pages/ReviewsPage"));
const ProfilePage = lazy(() => import("./pages/ProfilePage"));
const CalendarPage = lazy(() => import("./pages/CalendarPage"));
const SessionHistoryPage = lazy(
  () => import("./pages/SessionHistoryPage"),
);
const MonitorProfilePage = lazy(
  () => import("./pages/MonitorProfilePage"),
);
const FavoritesPage = lazy(() => import("./pages/FavoritesPage"));
const ChatPage = lazy(() => import("./pages/ChatPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const NotFoundPage = lazy(() => import("./pages/NotFoundPage"));

function Loader() {
  return (
    <div className="route-loader">
      <span className="route-loader__spinner" />
      <p>Carregando módulo...</p>
    </div>
  );
}

export default function App() {
  return (
    <AppErrorBoundary>
      <ThemeProvider>
        <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<MainLayout />}>
            <Route
              index
              element={<Navigate to="/dashboard" replace />}
            />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/mapa" element={<MapPage />} />
            <Route path="/monitores" element={<MonitorsPage />} />
            <Route
              path="/monitores/:id"
              element={<MonitorProfilePage />}
            />
            <Route path="/favoritos" element={<FavoritesPage />} />
            <Route path="/mensagens" element={<ChatPage />} />
            <Route path="/alunos" element={<StudentsPage />} />
            <Route path="/sessoes" element={<SessionsPage />} />
            <Route path="/agenda" element={<CalendarPage />} />
            <Route
              path="/historico"
              element={<SessionHistoryPage />}
            />
            <Route
              path="/instituicoes"
              element={<InstitutionsPage />}
            />
            <Route path="/disciplinas" element={<SubjectsPage />} />
            <Route
              path="/certificados"
              element={<CertificatesPage />}
            />
            <Route path="/avaliacoes" element={<ReviewsPage />} />
            <Route path="/perfil" element={<ProfilePage />} />
            <Route path="/configuracoes" element={<SettingsPage />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Suspense>
      </ThemeProvider>
    </AppErrorBoundary>
  );
}
